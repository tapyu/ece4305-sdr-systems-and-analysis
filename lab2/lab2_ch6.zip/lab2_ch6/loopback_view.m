close all
bcode =[  -1    -1    -1    -1    -1     1     1    -1    -1     1    -1     1    -1];
offset = 800;
packet_size = 500;

received=data;
subplot(2,1,1);
stem(received(end-offset:end-offset+packet_size-1));
subplot(2,1,2);
x=xcorr(received(end-offset:end-offset+packet_size),bcode);


plot(x(packet_size+1:end)); 
axis tight